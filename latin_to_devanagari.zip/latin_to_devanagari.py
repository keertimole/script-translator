from indic_transliteration import sanscript
from indic_transliteration.sanscript import transliterate
from tkinter import *
import pyttsx3
import espeakng

# Initialize pyttsx3 engine for fallback TTS
engine = pyttsx3.init()
engine.setProperty('rate', 150)  # Set speaking rate

# Retrieve the list of voices for pyttsx3
voices = engine.getProperty('voices')
print("Available Voices:")
for voice in voices:
    print(f"ID: {voice.id}, Name: {voice.name}, Languages: {voice.languages}")

# Initialize ESpeakNG Speaker object
esng = espeakng.Speaker()

# Function to clear both the text areas
def clearAll():
    text1_field.delete(1.0, END)
    text2_field.delete(1.0, END)

# Function to convert Latin text to Devanagari script
def convert():
    # Get the input content from the text box
    input_text = text1_field.get("1.0", "end").strip()

    # Convert to Devanagari script
    if input_text:
        # First, convert using Indic Transliteration
        output_text = transliterate(input_text, sanscript.ITRANS, sanscript.DEVANAGARI)
        
        # Debug: Print output after transliteration
        print(f"Transliterated text: {output_text}")
        
        # Apply manual fixes for common phrases
        output_text = fix_manual_translations(output_text)
        
        # Debug: Print output after manual fixes
        print(f"Fixed text: {output_text}")
        
        # Display the output in the second text field
        text2_field.delete(1.0, END)  # Clear the field before inserting new content
        text2_field.insert('end', output_text)
    else:
        text2_field.delete(1.0, END)

# Function to fix common phrase issues
def fix_manual_translations(output_text):
    custom_phrases = {
        "how are you": "कैसे हैं आप",
        "hello": "नमस्ते",
        "good morning": "सुप्रभात",
        "good night": "शुभ रात्रि",
        "thank you": "धन्यवाद",
        "please": "कृपया",
        "welcome": "स्वागत है",
        "how do you do": "कैसे हो आप?"
    }
    
    # Replace any recognized Latin phrases with the corresponding Devanagari phrases
    for latin, devnagari in custom_phrases.items():
        output_text = output_text.replace(latin, devnagari)
    
    return output_text

# Function to reverse transliterate Devanagari back to Latin
def reverse_convert():
    input_text = text2_field.get("1.0", "end").strip()

    if input_text:
        output_text = transliterate(input_text, sanscript.DEVANAGARI, sanscript.ITRANS)
        text1_field.delete(1.0, END)  # Clear the field before inserting new content
        text1_field.insert('end', output_text)
    else:
        text1_field.delete(1.0, END)

# Function to read the Devanagari text aloud
def speak_devanagari():
    devanagari_text = text2_field.get("1.0", "end").strip()

    if not devanagari_text:
        print("No text to speak.")
        return

    try:
        esng.say(devanagari_text)
    except Exception as espeak_error:
        print(f"ESpeakNG error: {espeak_error}. Falling back to pyttsx3.")
        try:
            engine.say(devanagari_text)
            engine.runAndWait()
        except Exception as pyttsx3_error:
            print(f"Error during speech synthesis with pyttsx3: {pyttsx3_error}")

# Function to save translated text to a file
def save_to_file():
    devanagari_text = text2_field.get("1.0", "end").strip()

    if devanagari_text:
        with open("translation_output.txt", "w", encoding="utf-8") as file:
            file.write(devanagari_text)
        print("Saved translation to translation_output.txt")
    else:
        print("No text to save.")

# Driver code to create the GUI
if __name__ == "__main__":
    root = Tk()
    root.configure(background='light green')
    root.geometry("500x500")
    root.title("Latin to Devanagari Translator with Voice Assistant")

    headlabel = Label(root, text='Welcome to Latin to Devanagari Converter with Voice', fg='black', bg="red")

    label1 = Label(root, text="Latin Text", fg='black', bg='dark green')
    label2 = Label(root, text="Devanagari Text", fg='black', bg='dark green')

    headlabel.grid(row=0, column=1)
    label1.grid(row=1, column=0, padx=10, pady=10)
    label2.grid(row=3, column=0, padx=10, pady=10)

    text1_field = Text(root, height=5, width=25, font="lucida 13")
    text2_field = Text(root, height=5, width=25, font="lucida 13")
    text1_field.grid(row=1, column=1, padx=10, pady=10)
    text2_field.grid(row=3, column=1, padx=10, pady=10)

    # Buttons
    button1 = Button(root, text="Convert to Devanagari Text", bg="red", fg="black", command=convert)
    button1.grid(row=2, column=1)

    button2 = Button(root, text="Clear", bg="red", fg="black", command=clearAll)
    button2.grid(row=4, column=1)

    button3 = Button(root, text="Speak", bg="blue", fg="white", command=speak_devanagari)
    button3.grid(row=5, column=1)

    button4 = Button(root, text="Reverse to Latin", bg="yellow", fg="black", command=reverse_convert)
    button4.grid(row=6, column=1)

    button5 = Button(root, text="Save to File", bg="green", fg="white", command=save_to_file)
    button5.grid(row=7, column=1)

    root.mainloop()
